import { Injectable } from '@angular/core';
import { Product } from '../Models/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  arrProduct:Product[] = []
  constructor() {
    this.arrProduct = [
      new Product(1,"laptop",70000, ""),
      new Product(2,"mouse",1600, ""),
      new Product(3,"keyboard",3000, ""),
      new Product(4,"smartphone",40000, ""),
      new Product(5,"mic",10000, "")
    ]
   }

   getProducts(){
    return this.arrProduct
   }

   addProduct(p:Product)
   {
    this.arrProduct.push(p)
    console.log(this.arrProduct)
   }

   updateProduct(arrProduct:Product[])
   {
    arrProduct[1].pName = "Computer" //pass id and Update
   }

   deleteProduct(arrProduct:Product[], id:number)
   {
    arrProduct.splice(id,1); //pass id
   }

   getProductById(id:number):Product{
    let p = new Product(0,'',0,'')
    for(var i=0;i<this.arrProduct.length;i++){
      if(this.arrProduct[i].id == id){
        console.log(this.arrProduct[i])
        return this.arrProduct[i]
      }
   }
   return p
  }

   updateThisProduct(p:Product){
    for(var i=0;i<this.arrProduct.length;i++){
      if(this.arrProduct[i].id == p.id){
        console.log(this.arrProduct[i])
        this.arrProduct[i] = p
      }
    }
    console.log(this.arrProduct)
   }
}
