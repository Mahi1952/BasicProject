export class Product{
    id:number
    pName:string
    price:number
    imgPath:string

    constructor(id:number, pName:string, price:number, imgPath:string)
    {
        this.id = id
        this.pName = pName
        this.price = price
        this.imgPath = imgPath
    }
}