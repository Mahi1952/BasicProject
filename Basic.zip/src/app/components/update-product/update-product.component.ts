import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Product } from '../../Models/product';
import { ProductService } from '../../services/product.service';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrl: './update-product.component.scss'
})
export class UpdateProductComponent {
  productForm: FormGroup;
  submitted!: true;
  arrProducts: Product[] = []
  product:Product = new Product(0,'',0,'')
  idUpdated:number = 0;

  constructor(private formBuilder:FormBuilder, private productService:ProductService){
    this.arrProducts = this.productService.getProducts()
    this.productForm = this.formBuilder.group({
      id:[0],
      pName:[''],
      price:[''],
      imgPath:['']
    })
  }
  get f() {return this.productForm.controls;}

  onSubmit(){
    this.submitted = true;
    let pN = this.productForm.value.pName;
    let pPr = this.productForm.value.price;
    let pId = this.productForm.value.id;
    let pImgPath = this.productForm.value.imgPath;

    if(pN && pPr && pId && pImgPath){
      this.product = new Product(this.idUpdated, pN, parseInt(pPr), pImgPath)
      this.productService.updateThisProduct(this.product);
    }
  }

  onChangeType(evt:any){
    console.log(evt.target.value);
    var idObtained = evt.target.value;
    this.idUpdated = parseInt(idObtained.split(':')[0].trim());
    console.log(this.idUpdated);
    this.product = this.productService.getProductById(this.idUpdated);

    this.productForm.get('pName')?.setValue(this.product.pName)
    this.productForm.get('price')?.setValue(this.product.price)
    this.productForm.get('img_path')?.setValue(this.product.imgPath)
  }
}
